/**
 * null
 */
package api.gw.stage.demo.model.transform;

import javax.annotation.Generated;

import com.amazonaws.SdkClientException;
import api.gw.stage.demo.model.*;

import com.amazonaws.protocol.*;
import com.amazonaws.annotation.SdkInternalApi;

/**
 * GetGoogleRequestMarshaller
 */
@Generated("com.amazonaws:aws-java-sdk-code-generator")
@SdkInternalApi
public class GetGoogleRequestMarshaller {

    private static final GetGoogleRequestMarshaller instance = new GetGoogleRequestMarshaller();

    public static GetGoogleRequestMarshaller getInstance() {
        return instance;
    }

    /**
     * Marshall the given parameter object.
     */
    public void marshall(GetGoogleRequest getGoogleRequest, ProtocolMarshaller protocolMarshaller) {

        if (getGoogleRequest == null) {
            throw new SdkClientException("Invalid argument passed to marshall(...)");
        }

        try {
        } catch (Exception e) {
            throw new SdkClientException("Unable to marshall request to JSON: " + e.getMessage(), e);
        }
    }

}
