/**
 * null
 */
package api.gw.stage.demo;

import javax.annotation.Generated;
import api.gw.stage.demo.model.*;
import com.amazonaws.*;
import com.amazonaws.opensdk.*;
import com.amazonaws.opensdk.model.*;

/**
 * Abstract implementation of {@code apiGoogle}.
 */
@Generated("com.amazonaws:aws-java-sdk-code-generator")
public class AbstractapiGoogle implements apiGoogle {

    protected AbstractapiGoogle() {
    }

    @Override
    public GetCipResult getCip(GetCipRequest request) {
        throw new java.lang.UnsupportedOperationException();
    }

    @Override
    public GetCipInfoResult getCipInfo(GetCipInfoRequest request) {
        throw new java.lang.UnsupportedOperationException();
    }

    @Override
    public GetCupResult getCup(GetCupRequest request) {
        throw new java.lang.UnsupportedOperationException();
    }

    @Override
    public GetGoogleResult getGoogle(GetGoogleRequest request) {
        throw new java.lang.UnsupportedOperationException();
    }

    @Override
    public PostCipResult postCip(PostCipRequest request) {
        throw new java.lang.UnsupportedOperationException();
    }

    @Override
    public PostCupResult postCup(PostCupRequest request) {
        throw new java.lang.UnsupportedOperationException();
    }

    @Override
    public PostGoogleResult postGoogle(PostGoogleRequest request) {
        throw new java.lang.UnsupportedOperationException();
    }

    @Override
    public void shutdown() {
        throw new java.lang.UnsupportedOperationException();
    }

}
