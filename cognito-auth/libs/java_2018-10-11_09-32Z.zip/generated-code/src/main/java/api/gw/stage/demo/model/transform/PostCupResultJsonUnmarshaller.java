/**
 * null
 */
package api.gw.stage.demo.model.transform;

import java.math.*;

import javax.annotation.Generated;

import api.gw.stage.demo.model.*;
import com.amazonaws.transform.SimpleTypeJsonUnmarshallers.*;
import com.amazonaws.transform.*;

import com.fasterxml.jackson.core.JsonToken;
import static com.fasterxml.jackson.core.JsonToken.*;

/**
 * PostCupResult JSON Unmarshaller
 */
@Generated("com.amazonaws:aws-java-sdk-code-generator")
public class PostCupResultJsonUnmarshaller implements Unmarshaller<PostCupResult, JsonUnmarshallerContext> {

    public PostCupResult unmarshall(JsonUnmarshallerContext context) throws Exception {
        PostCupResult postCupResult = new PostCupResult();

        int originalDepth = context.getCurrentDepth();
        String currentParentElement = context.getCurrentParentElement();
        int targetDepth = originalDepth + 1;

        JsonToken token = context.getCurrentToken();
        if (token == null)
            token = context.nextToken();
        if (token == VALUE_NULL) {
            return postCupResult;
        }

        while (true) {
            if (token == null)
                break;

            postCupResult.setEmpty(EmptyJsonUnmarshaller.getInstance().unmarshall(context));
            token = context.nextToken();
        }

        return postCupResult;
    }

    private static PostCupResultJsonUnmarshaller instance;

    public static PostCupResultJsonUnmarshaller getInstance() {
        if (instance == null)
            instance = new PostCupResultJsonUnmarshaller();
        return instance;
    }
}
