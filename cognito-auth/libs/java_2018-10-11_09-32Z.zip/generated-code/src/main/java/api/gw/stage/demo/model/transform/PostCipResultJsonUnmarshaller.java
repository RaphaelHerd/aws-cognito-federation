/**
 * null
 */
package api.gw.stage.demo.model.transform;

import java.math.*;

import javax.annotation.Generated;

import api.gw.stage.demo.model.*;
import com.amazonaws.transform.SimpleTypeJsonUnmarshallers.*;
import com.amazonaws.transform.*;

import com.fasterxml.jackson.core.JsonToken;
import static com.fasterxml.jackson.core.JsonToken.*;

/**
 * PostCipResult JSON Unmarshaller
 */
@Generated("com.amazonaws:aws-java-sdk-code-generator")
public class PostCipResultJsonUnmarshaller implements Unmarshaller<PostCipResult, JsonUnmarshallerContext> {

    public PostCipResult unmarshall(JsonUnmarshallerContext context) throws Exception {
        PostCipResult postCipResult = new PostCipResult();

        int originalDepth = context.getCurrentDepth();
        String currentParentElement = context.getCurrentParentElement();
        int targetDepth = originalDepth + 1;

        JsonToken token = context.getCurrentToken();
        if (token == null)
            token = context.nextToken();
        if (token == VALUE_NULL) {
            return postCipResult;
        }

        while (true) {
            if (token == null)
                break;

            postCipResult.setEmpty(EmptyJsonUnmarshaller.getInstance().unmarshall(context));
            token = context.nextToken();
        }

        return postCipResult;
    }

    private static PostCipResultJsonUnmarshaller instance;

    public static PostCipResultJsonUnmarshaller getInstance() {
        if (instance == null)
            instance = new PostCipResultJsonUnmarshaller();
        return instance;
    }
}
