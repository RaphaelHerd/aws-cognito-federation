/**
 * null
 */
package api.gw.stage.demo.model.transform;

import javax.annotation.Generated;

import com.amazonaws.SdkClientException;
import api.gw.stage.demo.model.*;

import com.amazonaws.protocol.*;
import com.amazonaws.annotation.SdkInternalApi;

/**
 * PostCupRequestMarshaller
 */
@Generated("com.amazonaws:aws-java-sdk-code-generator")
@SdkInternalApi
public class PostCupRequestMarshaller {

    private static final PostCupRequestMarshaller instance = new PostCupRequestMarshaller();

    public static PostCupRequestMarshaller getInstance() {
        return instance;
    }

    /**
     * Marshall the given parameter object.
     */
    public void marshall(PostCupRequest postCupRequest, ProtocolMarshaller protocolMarshaller) {

        if (postCupRequest == null) {
            throw new SdkClientException("Invalid argument passed to marshall(...)");
        }

        try {
        } catch (Exception e) {
            throw new SdkClientException("Unable to marshall request to JSON: " + e.getMessage(), e);
        }
    }

}
