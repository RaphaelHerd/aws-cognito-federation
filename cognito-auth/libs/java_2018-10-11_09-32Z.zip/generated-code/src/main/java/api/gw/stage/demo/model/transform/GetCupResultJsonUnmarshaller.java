/**
 * null
 */
package api.gw.stage.demo.model.transform;

import java.math.*;

import javax.annotation.Generated;

import api.gw.stage.demo.model.*;
import com.amazonaws.transform.SimpleTypeJsonUnmarshallers.*;
import com.amazonaws.transform.*;

import com.fasterxml.jackson.core.JsonToken;
import static com.fasterxml.jackson.core.JsonToken.*;

/**
 * GetCupResult JSON Unmarshaller
 */
@Generated("com.amazonaws:aws-java-sdk-code-generator")
public class GetCupResultJsonUnmarshaller implements Unmarshaller<GetCupResult, JsonUnmarshallerContext> {

    public GetCupResult unmarshall(JsonUnmarshallerContext context) throws Exception {
        GetCupResult getCupResult = new GetCupResult();

        int originalDepth = context.getCurrentDepth();
        String currentParentElement = context.getCurrentParentElement();
        int targetDepth = originalDepth + 1;

        JsonToken token = context.getCurrentToken();
        if (token == null)
            token = context.nextToken();
        if (token == VALUE_NULL) {
            return getCupResult;
        }

        while (true) {
            if (token == null)
                break;

            getCupResult.setEmpty(EmptyJsonUnmarshaller.getInstance().unmarshall(context));
            token = context.nextToken();
        }

        return getCupResult;
    }

    private static GetCupResultJsonUnmarshaller instance;

    public static GetCupResultJsonUnmarshaller getInstance() {
        if (instance == null)
            instance = new GetCupResultJsonUnmarshaller();
        return instance;
    }
}
