/**
 * null
 */
package api.gw.stage.demo;

import javax.annotation.Generated;

import com.amazonaws.*;
import com.amazonaws.opensdk.*;
import com.amazonaws.opensdk.model.*;
import com.amazonaws.regions.*;

import api.gw.stage.demo.model.*;

/**
 * Interface for accessing apiGoogle.
 */
@Generated("com.amazonaws:aws-java-sdk-code-generator")
public interface apiGoogle {

    /**
     * @param getCipRequest
     * @return Result of the GetCip operation returned by the service.
     * @sample apiGoogle.GetCip
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/GetCip" target="_top">AWS
     *      API Documentation</a>
     */
    GetCipResult getCip(GetCipRequest getCipRequest);

    /**
     * @param getCipInfoRequest
     * @return Result of the GetCipInfo operation returned by the service.
     * @sample apiGoogle.GetCipInfo
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/GetCipInfo"
     *      target="_top">AWS API Documentation</a>
     */
    GetCipInfoResult getCipInfo(GetCipInfoRequest getCipInfoRequest);

    /**
     * @param getCupRequest
     * @return Result of the GetCup operation returned by the service.
     * @sample apiGoogle.GetCup
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/GetCup" target="_top">AWS
     *      API Documentation</a>
     */
    GetCupResult getCup(GetCupRequest getCupRequest);

    /**
     * @param getGoogleRequest
     * @return Result of the GetGoogle operation returned by the service.
     * @sample apiGoogle.GetGoogle
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/GetGoogle" target="_top">AWS
     *      API Documentation</a>
     */
    GetGoogleResult getGoogle(GetGoogleRequest getGoogleRequest);

    /**
     * @param postCipRequest
     * @return Result of the PostCip operation returned by the service.
     * @sample apiGoogle.PostCip
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/PostCip" target="_top">AWS
     *      API Documentation</a>
     */
    PostCipResult postCip(PostCipRequest postCipRequest);

    /**
     * @param postCupRequest
     * @return Result of the PostCup operation returned by the service.
     * @sample apiGoogle.PostCup
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/PostCup" target="_top">AWS
     *      API Documentation</a>
     */
    PostCupResult postCup(PostCupRequest postCupRequest);

    /**
     * @param postGoogleRequest
     * @return Result of the PostGoogle operation returned by the service.
     * @sample apiGoogle.PostGoogle
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/PostGoogle"
     *      target="_top">AWS API Documentation</a>
     */
    PostGoogleResult postGoogle(PostGoogleRequest postGoogleRequest);

    /**
     * @return Create new instance of builder with all defaults set.
     */
    public static apiGoogleClientBuilder builder() {
        return new apiGoogleClientBuilder();
    }

    /**
     * Shuts down this client object, releasing any resources that might be held open. This is an optional method, and
     * callers are not expected to call it, but can if they want to explicitly release any open resources. Once a client
     * has been shutdown, it should not be used to make any more requests.
     */
    void shutdown();

}
