/**
 * null
 */
package api.gw.stage.demo.model.transform;

import java.math.*;

import javax.annotation.Generated;

import api.gw.stage.demo.model.*;
import com.amazonaws.transform.SimpleTypeJsonUnmarshallers.*;
import com.amazonaws.transform.*;

import com.fasterxml.jackson.core.JsonToken;
import static com.fasterxml.jackson.core.JsonToken.*;

/**
 * PostGoogleResult JSON Unmarshaller
 */
@Generated("com.amazonaws:aws-java-sdk-code-generator")
public class PostGoogleResultJsonUnmarshaller implements Unmarshaller<PostGoogleResult, JsonUnmarshallerContext> {

    public PostGoogleResult unmarshall(JsonUnmarshallerContext context) throws Exception {
        PostGoogleResult postGoogleResult = new PostGoogleResult();

        int originalDepth = context.getCurrentDepth();
        String currentParentElement = context.getCurrentParentElement();
        int targetDepth = originalDepth + 1;

        JsonToken token = context.getCurrentToken();
        if (token == null)
            token = context.nextToken();
        if (token == VALUE_NULL) {
            return postGoogleResult;
        }

        while (true) {
            if (token == null)
                break;

            postGoogleResult.setEmpty(EmptyJsonUnmarshaller.getInstance().unmarshall(context));
            token = context.nextToken();
        }

        return postGoogleResult;
    }

    private static PostGoogleResultJsonUnmarshaller instance;

    public static PostGoogleResultJsonUnmarshaller getInstance() {
        if (instance == null)
            instance = new PostGoogleResultJsonUnmarshaller();
        return instance;
    }
}
