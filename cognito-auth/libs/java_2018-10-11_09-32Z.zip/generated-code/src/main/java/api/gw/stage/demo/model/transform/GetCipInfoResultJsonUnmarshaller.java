/**
 * null
 */
package api.gw.stage.demo.model.transform;

import java.math.*;

import javax.annotation.Generated;

import api.gw.stage.demo.model.*;
import com.amazonaws.transform.SimpleTypeJsonUnmarshallers.*;
import com.amazonaws.transform.*;

import com.fasterxml.jackson.core.JsonToken;
import static com.fasterxml.jackson.core.JsonToken.*;

/**
 * GetCipInfoResult JSON Unmarshaller
 */
@Generated("com.amazonaws:aws-java-sdk-code-generator")
public class GetCipInfoResultJsonUnmarshaller implements Unmarshaller<GetCipInfoResult, JsonUnmarshallerContext> {

    public GetCipInfoResult unmarshall(JsonUnmarshallerContext context) throws Exception {
        GetCipInfoResult getCipInfoResult = new GetCipInfoResult();

        int originalDepth = context.getCurrentDepth();
        String currentParentElement = context.getCurrentParentElement();
        int targetDepth = originalDepth + 1;

        JsonToken token = context.getCurrentToken();
        if (token == null)
            token = context.nextToken();
        if (token == VALUE_NULL) {
            return getCipInfoResult;
        }

        while (true) {
            if (token == null)
                break;

            getCipInfoResult.setEmpty(EmptyJsonUnmarshaller.getInstance().unmarshall(context));
            token = context.nextToken();
        }

        return getCipInfoResult;
    }

    private static GetCipInfoResultJsonUnmarshaller instance;

    public static GetCipInfoResultJsonUnmarshaller getInstance() {
        if (instance == null)
            instance = new GetCipInfoResultJsonUnmarshaller();
        return instance;
    }
}
