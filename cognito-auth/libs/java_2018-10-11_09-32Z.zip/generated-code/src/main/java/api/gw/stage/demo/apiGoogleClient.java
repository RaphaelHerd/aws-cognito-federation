/**
 * null
 */
package api.gw.stage.demo;

import java.net.*;
import java.util.*;

import javax.annotation.Generated;

import org.apache.commons.logging.*;

import com.amazonaws.*;
import com.amazonaws.opensdk.*;
import com.amazonaws.opensdk.model.*;
import com.amazonaws.opensdk.protect.model.transform.*;
import com.amazonaws.auth.*;
import com.amazonaws.handlers.*;
import com.amazonaws.http.*;
import com.amazonaws.internal.*;
import com.amazonaws.metrics.*;
import com.amazonaws.regions.*;
import com.amazonaws.transform.*;
import com.amazonaws.util.*;
import com.amazonaws.protocol.json.*;

import com.amazonaws.annotation.ThreadSafe;
import com.amazonaws.client.AwsSyncClientParams;

import com.amazonaws.client.ClientHandler;
import com.amazonaws.client.ClientHandlerParams;
import com.amazonaws.client.ClientExecutionParams;
import com.amazonaws.opensdk.protect.client.SdkClientHandler;
import com.amazonaws.SdkBaseException;

import api.gw.stage.demo.model.*;
import api.gw.stage.demo.model.transform.*;

/**
 * Client for accessing apiGoogle. All service calls made using this client are blocking, and will not return until the
 * service call completes.
 * <p>
 * 
 */
@ThreadSafe
@Generated("com.amazonaws:aws-java-sdk-code-generator")
class apiGoogleClient implements apiGoogle {

    private final ClientHandler clientHandler;

    private static final com.amazonaws.opensdk.protect.protocol.ApiGatewayProtocolFactoryImpl protocolFactory = new com.amazonaws.opensdk.protect.protocol.ApiGatewayProtocolFactoryImpl(
            new JsonClientMetadata().withProtocolVersion("1.1").withSupportsCbor(false).withSupportsIon(false).withContentTypeOverride("application/json")
                    .withBaseServiceExceptionClass(api.gw.stage.demo.model.apiGoogleException.class));

    /**
     * Constructs a new client to invoke service methods on apiGoogle using the specified parameters.
     *
     * <p>
     * All service calls made using this new client object are blocking, and will not return until the service call
     * completes.
     *
     * @param clientParams
     *        Object providing client parameters.
     */
    apiGoogleClient(AwsSyncClientParams clientParams) {
        this.clientHandler = new SdkClientHandler(new ClientHandlerParams().withClientParams(clientParams));
    }

    /**
     * @param getCipRequest
     * @return Result of the GetCip operation returned by the service.
     * @sample apiGoogle.GetCip
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/GetCip" target="_top">AWS
     *      API Documentation</a>
     */
    @Override
    public GetCipResult getCip(GetCipRequest getCipRequest) {
        HttpResponseHandler<GetCipResult> responseHandler = protocolFactory.createResponseHandler(new JsonOperationMetadata().withPayloadJson(true)
                .withHasStreamingSuccessResponse(false), new GetCipResultJsonUnmarshaller());

        HttpResponseHandler<SdkBaseException> errorResponseHandler = createErrorResponseHandler();

        return clientHandler.execute(new ClientExecutionParams<GetCipRequest, GetCipResult>()
                .withMarshaller(new GetCipRequestProtocolMarshaller(protocolFactory)).withResponseHandler(responseHandler)
                .withErrorResponseHandler(errorResponseHandler).withInput(getCipRequest));
    }

    /**
     * @param getCipInfoRequest
     * @return Result of the GetCipInfo operation returned by the service.
     * @sample apiGoogle.GetCipInfo
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/GetCipInfo"
     *      target="_top">AWS API Documentation</a>
     */
    @Override
    public GetCipInfoResult getCipInfo(GetCipInfoRequest getCipInfoRequest) {
        HttpResponseHandler<GetCipInfoResult> responseHandler = protocolFactory.createResponseHandler(new JsonOperationMetadata().withPayloadJson(true)
                .withHasStreamingSuccessResponse(false), new GetCipInfoResultJsonUnmarshaller());

        HttpResponseHandler<SdkBaseException> errorResponseHandler = createErrorResponseHandler();

        return clientHandler.execute(new ClientExecutionParams<GetCipInfoRequest, GetCipInfoResult>()
                .withMarshaller(new GetCipInfoRequestProtocolMarshaller(protocolFactory)).withResponseHandler(responseHandler)
                .withErrorResponseHandler(errorResponseHandler).withInput(getCipInfoRequest));
    }

    /**
     * @param getCupRequest
     * @return Result of the GetCup operation returned by the service.
     * @sample apiGoogle.GetCup
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/GetCup" target="_top">AWS
     *      API Documentation</a>
     */
    @Override
    public GetCupResult getCup(GetCupRequest getCupRequest) {
        HttpResponseHandler<GetCupResult> responseHandler = protocolFactory.createResponseHandler(new JsonOperationMetadata().withPayloadJson(true)
                .withHasStreamingSuccessResponse(false), new GetCupResultJsonUnmarshaller());

        HttpResponseHandler<SdkBaseException> errorResponseHandler = createErrorResponseHandler();

        return clientHandler.execute(new ClientExecutionParams<GetCupRequest, GetCupResult>()
                .withMarshaller(new GetCupRequestProtocolMarshaller(protocolFactory)).withResponseHandler(responseHandler)
                .withErrorResponseHandler(errorResponseHandler).withInput(getCupRequest));
    }

    /**
     * @param getGoogleRequest
     * @return Result of the GetGoogle operation returned by the service.
     * @sample apiGoogle.GetGoogle
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/GetGoogle" target="_top">AWS
     *      API Documentation</a>
     */
    @Override
    public GetGoogleResult getGoogle(GetGoogleRequest getGoogleRequest) {
        HttpResponseHandler<GetGoogleResult> responseHandler = protocolFactory.createResponseHandler(new JsonOperationMetadata().withPayloadJson(true)
                .withHasStreamingSuccessResponse(false), new GetGoogleResultJsonUnmarshaller());

        HttpResponseHandler<SdkBaseException> errorResponseHandler = createErrorResponseHandler();

        return clientHandler.execute(new ClientExecutionParams<GetGoogleRequest, GetGoogleResult>()
                .withMarshaller(new GetGoogleRequestProtocolMarshaller(protocolFactory)).withResponseHandler(responseHandler)
                .withErrorResponseHandler(errorResponseHandler).withInput(getGoogleRequest));
    }

    /**
     * @param postCipRequest
     * @return Result of the PostCip operation returned by the service.
     * @sample apiGoogle.PostCip
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/PostCip" target="_top">AWS
     *      API Documentation</a>
     */
    @Override
    public PostCipResult postCip(PostCipRequest postCipRequest) {
        HttpResponseHandler<PostCipResult> responseHandler = protocolFactory.createResponseHandler(new JsonOperationMetadata().withPayloadJson(true)
                .withHasStreamingSuccessResponse(false), new PostCipResultJsonUnmarshaller());

        HttpResponseHandler<SdkBaseException> errorResponseHandler = createErrorResponseHandler();

        return clientHandler.execute(new ClientExecutionParams<PostCipRequest, PostCipResult>()
                .withMarshaller(new PostCipRequestProtocolMarshaller(protocolFactory)).withResponseHandler(responseHandler)
                .withErrorResponseHandler(errorResponseHandler).withInput(postCipRequest));
    }

    /**
     * @param postCupRequest
     * @return Result of the PostCup operation returned by the service.
     * @sample apiGoogle.PostCup
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/PostCup" target="_top">AWS
     *      API Documentation</a>
     */
    @Override
    public PostCupResult postCup(PostCupRequest postCupRequest) {
        HttpResponseHandler<PostCupResult> responseHandler = protocolFactory.createResponseHandler(new JsonOperationMetadata().withPayloadJson(true)
                .withHasStreamingSuccessResponse(false), new PostCupResultJsonUnmarshaller());

        HttpResponseHandler<SdkBaseException> errorResponseHandler = createErrorResponseHandler();

        return clientHandler.execute(new ClientExecutionParams<PostCupRequest, PostCupResult>()
                .withMarshaller(new PostCupRequestProtocolMarshaller(protocolFactory)).withResponseHandler(responseHandler)
                .withErrorResponseHandler(errorResponseHandler).withInput(postCupRequest));
    }

    /**
     * @param postGoogleRequest
     * @return Result of the PostGoogle operation returned by the service.
     * @sample apiGoogle.PostGoogle
     * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/hax2ng58h3-2017-04-26T03:23:48Z/PostGoogle"
     *      target="_top">AWS API Documentation</a>
     */
    @Override
    public PostGoogleResult postGoogle(PostGoogleRequest postGoogleRequest) {
        HttpResponseHandler<PostGoogleResult> responseHandler = protocolFactory.createResponseHandler(new JsonOperationMetadata().withPayloadJson(true)
                .withHasStreamingSuccessResponse(false), new PostGoogleResultJsonUnmarshaller());

        HttpResponseHandler<SdkBaseException> errorResponseHandler = createErrorResponseHandler();

        return clientHandler.execute(new ClientExecutionParams<PostGoogleRequest, PostGoogleResult>()
                .withMarshaller(new PostGoogleRequestProtocolMarshaller(protocolFactory)).withResponseHandler(responseHandler)
                .withErrorResponseHandler(errorResponseHandler).withInput(postGoogleRequest));
    }

    /**
     * Create the error response handler for the operation.
     * 
     * @param errorShapeMetadata
     *        Error metadata for the given operation
     * @return Configured error response handler to pass to HTTP layer
     */
    private HttpResponseHandler<SdkBaseException> createErrorResponseHandler(JsonErrorShapeMetadata... errorShapeMetadata) {
        return protocolFactory.createErrorResponseHandler(new JsonErrorResponseMetadata().withErrorShapes(Arrays.asList(errorShapeMetadata)));
    }

    @Override
    public void shutdown() {
        clientHandler.shutdown();
    }

}
