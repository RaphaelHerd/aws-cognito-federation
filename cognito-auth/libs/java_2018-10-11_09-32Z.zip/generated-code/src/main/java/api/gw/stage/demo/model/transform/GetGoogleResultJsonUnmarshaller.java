/**
 * null
 */
package api.gw.stage.demo.model.transform;

import java.math.*;

import javax.annotation.Generated;

import api.gw.stage.demo.model.*;
import com.amazonaws.transform.SimpleTypeJsonUnmarshallers.*;
import com.amazonaws.transform.*;

import com.fasterxml.jackson.core.JsonToken;
import static com.fasterxml.jackson.core.JsonToken.*;

/**
 * GetGoogleResult JSON Unmarshaller
 */
@Generated("com.amazonaws:aws-java-sdk-code-generator")
public class GetGoogleResultJsonUnmarshaller implements Unmarshaller<GetGoogleResult, JsonUnmarshallerContext> {

    public GetGoogleResult unmarshall(JsonUnmarshallerContext context) throws Exception {
        GetGoogleResult getGoogleResult = new GetGoogleResult();

        int originalDepth = context.getCurrentDepth();
        String currentParentElement = context.getCurrentParentElement();
        int targetDepth = originalDepth + 1;

        JsonToken token = context.getCurrentToken();
        if (token == null)
            token = context.nextToken();
        if (token == VALUE_NULL) {
            return getGoogleResult;
        }

        while (true) {
            if (token == null)
                break;

            getGoogleResult.setEmpty(EmptyJsonUnmarshaller.getInstance().unmarshall(context));
            token = context.nextToken();
        }

        return getGoogleResult;
    }

    private static GetGoogleResultJsonUnmarshaller instance;

    public static GetGoogleResultJsonUnmarshaller getInstance() {
        if (instance == null)
            instance = new GetGoogleResultJsonUnmarshaller();
        return instance;
    }
}
