/**
 * null
 */
package api.gw.stage.demo.model.transform;

import javax.annotation.Generated;

import com.amazonaws.SdkClientException;
import api.gw.stage.demo.model.*;

import com.amazonaws.protocol.*;
import com.amazonaws.annotation.SdkInternalApi;

/**
 * GetCipInfoRequestMarshaller
 */
@Generated("com.amazonaws:aws-java-sdk-code-generator")
@SdkInternalApi
public class GetCipInfoRequestMarshaller {

    private static final GetCipInfoRequestMarshaller instance = new GetCipInfoRequestMarshaller();

    public static GetCipInfoRequestMarshaller getInstance() {
        return instance;
    }

    /**
     * Marshall the given parameter object.
     */
    public void marshall(GetCipInfoRequest getCipInfoRequest, ProtocolMarshaller protocolMarshaller) {

        if (getCipInfoRequest == null) {
            throw new SdkClientException("Invalid argument passed to marshall(...)");
        }

        try {
        } catch (Exception e) {
            throw new SdkClientException("Unable to marshall request to JSON: " + e.getMessage(), e);
        }
    }

}
